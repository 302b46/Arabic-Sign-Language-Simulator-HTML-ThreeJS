# Arabic-Sign-Language-Simulator
The Arabic Sign Language Simulator is a three.js-based program. Its purpose is to introduce people to the signs of the Arabic alphabet in Arabic Sign Language (ArSL). A sign language is a system of communication using visual hand gestures and signs, and it was created to ease socializing with deaf people or people who are hard of hearing.
