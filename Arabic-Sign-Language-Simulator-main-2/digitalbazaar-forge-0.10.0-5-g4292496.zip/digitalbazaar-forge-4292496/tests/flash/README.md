Flash Cross-Domain URLLoader Test
=================================

Note: out of date.

See the main forge `flash/README.md` and `flash/package.json` for hints on how
to build this code.
