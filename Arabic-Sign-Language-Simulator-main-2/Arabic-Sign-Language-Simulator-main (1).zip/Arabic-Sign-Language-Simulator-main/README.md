# Arabic-Sign-Language-Simulator
A prototype simulator for the Arabic alphabets in Arabic Sign Language. (made using Three.js)
