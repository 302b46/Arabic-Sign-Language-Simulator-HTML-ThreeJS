# json-fonts
TextGeometry json fonts (THREE.js, AFRAME, etc.) Arabic Bengali Cyrillic Devanagari Greek Gujarati Gurmukhi Hebrew Kannada Khmer Latin Malayalam Myanm ar Oriya Sinhala Tamil Telugu Thai Vietnamese

## Fonts
- [x] Roboto
- [ ] Noto

### Langs

- [ ] Arabic
- [ ] Bengali
- [ ] Cyrillic
- [ ] Cyrillic Extended
- [ ] Devanagari
- [ ] Greek
- [ ] Greek Extended
- [ ] Gujarati
- [ ] Gurmukhi
- [ ] Hebrew
- [ ] Kannada
- [ ] Khmer
- [ ] Latin
- [ ] Latin Extended
- [ ] Malayalam
- [ ] Myanmar
- [ ] Oriya
- [ ] Sinhala
- [ ] Tamil
- [ ] Telugu
- [ ] Thai
- [ ] Vietnamese

https://fonts.google.com/earlyaccess

- [ ] cwTeXKai font (Chinese: 楷體) is derived from the cwTeX Traditional Chinese Type 1 fonts made by Tsong-Min Wu, Tsong-Huey Wu and Edward G.J. Lee.

PR are welcome
